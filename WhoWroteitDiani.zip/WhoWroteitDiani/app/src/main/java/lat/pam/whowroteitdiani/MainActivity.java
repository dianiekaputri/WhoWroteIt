package lat.pam.whowroteitdiani;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public EditText mBookInput;
    public TextView penulis;
    public TextView judul;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mBookInput = (EditText)findViewById(R.id.book_input);
        penulis = (TextView)findViewById(R.id.author_text);
        judul = (TextView)findViewById(R.id.title_text);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void searchBooks(View view){
        String queryString = mBookInput.getText().toString();
        new FetchBook(judul, penulis).execute(queryString);
    }
}